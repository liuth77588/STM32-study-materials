#ifndef __TIMER_H
#define __TIMER_H


void TIM6_Init(void);

#endif
