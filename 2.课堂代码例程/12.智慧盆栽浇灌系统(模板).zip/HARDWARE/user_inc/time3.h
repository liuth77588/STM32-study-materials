#ifndef __TIME3_H
#define __TIME3_H

void TIM3_IntInit(void);



#endif


