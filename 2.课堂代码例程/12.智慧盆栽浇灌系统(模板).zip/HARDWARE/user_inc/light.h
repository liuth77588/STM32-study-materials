#ifndef __LIGHT_H
#define __LIGHT_H

#include "public.h"


#endif

