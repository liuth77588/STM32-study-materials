/**
  ******************************************************************************
  * @file    Project/STM32F4xx_StdPeriph_Templates/stm32f4xx_it.c 
  * @author  MCD Application Team
  * @version V1.4.0
  * @date    04-August-2014
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_it.h"


/** @addtogroup Template_Project
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/


__IO uint16_t IC1Value=0; //TIM8 IC1��ֵ
__IO uint16_t IC2Value=0; //TIM8 IC2��ֵ

__IO float DutyCycle=0;   //������ռ�ձ�
__IO float Frequency=0;   //Ƶ��

void TIM8_CC_IRQHandler(void)
{
	
	if (TIM_GetITStatus(TIM8, TIM_IT_CC1) == SET)
	{
		TIM_ClearITPendingBit(TIM8, TIM_IT_CC1);
		/* ��ȡ���벶���ֵ*/
		IC1Value = TIM_GetCapture1(TIM8);
		IC2Value = TIM_GetCapture2(TIM8);
		
		if(IC1Value!=0)
		{
			//ռ�ձ�
			DutyCycle=(float)(IC2Value+1)/(IC1Value+1)*100;
			
			//Ƶ��
			Frequency= (168000000/168)/(float)IC1Value;	
			
		}
		else
		{
			//���ں�����Ϊ0
			DutyCycle=0;
			Frequency=0;
		}
		
		
		
	}
	
	
	
	
	 

}


















/**
  * @brief  ��ʱ��6�жϷ�����
  * @note   
  * @param  void
  * @retval None
  */
void TIM6_DAC_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM6, TIM_IT_Update) == SET)
	{
		GPIO_ToggleBits(GPIOF,GPIO_Pin_9);
	}
	TIM_ClearITPendingBit(TIM6, TIM_IT_Update);
}






/**
  * @brief  �ⲿ�ж���·2���жϷ�����
  * @note   ����PE2����һ���жϣ���ִ��һ�α�����
  * @param  void 
  * @retval None
  */
void EXTI2_IRQHandler(void)
{
	//��дEXTI2���жϷ������������жϺ�LED��תһ��
   if(EXTI_GetITStatus(EXTI_Line2) == SET)
   {
    /* Toggle LED1 */
     GPIO_ToggleBits(GPIOF,GPIO_Pin_10);
	 while(1)  //��ѭ����ʹ����һֱͣ�����жϷ�������
	 {
		
	 }
     /* Clear the EXTI line 0 pending bit */
     EXTI_ClearITPendingBit(EXTI_Line2);
   }
}

void EXTI3_IRQHandler(void)
{
	
   if(EXTI_GetITStatus(EXTI_Line3) == SET)
   {
    /* Toggle LED1 */
     GPIO_ToggleBits(GPIOF,GPIO_Pin_9);
	   
     /* Clear the EXTI line 0 pending bit */
     EXTI_ClearITPendingBit(EXTI_Line3);
   }
}
/*

�жϱ�־λ�������ж����������������������ú��жϷ�����������
һ�������жϱ�־λ��Ч����˵����ִ���жϷ������ˡ�
������ǲ��ֶ�������жϱ�־λ��
��ôϵͳ��Ĭ���ж�����һֱ�����Ǿͻ�һֱִ���жϷ��������������ˡ�

*/


/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
 
}

/******************************************************************************/
/*                 STM32F4xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f4xx.s).                                               */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
