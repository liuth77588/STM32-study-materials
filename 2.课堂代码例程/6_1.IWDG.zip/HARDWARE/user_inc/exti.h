#ifndef __EXTI_H
#define __EXTI_H

void EXTI_Init_Key(void);

#endif
