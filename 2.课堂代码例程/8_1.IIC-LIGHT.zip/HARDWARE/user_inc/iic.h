#ifndef __IIC_H
#define __IIC_H

#include "public.h"
//ѡ��PE3��PE4 ��ΪͨѶ����  PE3:SCL  PE4��SDA

#define RCC_IIC_SCL   RCC_AHB1Periph_GPIOE //�˿�ʱ��
#define IIC_SCL_PORT  GPIOE				   //�˿ں�
#define IIC_SCL 	  GPIO_Pin_3		   //����

#define RCC_IIC_SDA   RCC_AHB1Periph_GPIOE
#define	IIC_SDA_PORT  GPIOE
#define	IIC_SDA 	  GPIO_Pin_4

//io����

#define IIC_SCL_H     GPIO_SetBits(IIC_SCL_PORT,IIC_SCL);  //SCL��1
#define	IIC_SCL_L     GPIO_ResetBits(IIC_SCL_PORT,IIC_SCL);//SCL��0

#define IIC_SDA_H     GPIO_SetBits(IIC_SDA_PORT,IIC_SDA);  //SDA��1
#define	IIC_SDA_L     GPIO_ResetBits(IIC_SDA_PORT,IIC_SDA);//SDA��0

#define READ_SDA 	  GPIO_ReadInputDataBit(IIC_SDA_PORT,IIC_SDA)//��ȡSDA�������ŵ�ƽ

void IICx_GPIO_Init(void);
void IIC_SDA_OUT(void);
void IIC_SDA_IN(void);
void IIC_Start(void);
void IIC_Stop(void);
void IIC_ACK(void);
void IIC_NACK(void);
void IIC_SendByte(uint8_t data);
uint8_t IIC_ReadByte(uint8_t ack);
uint8_t IIC_WaitACK(void);
uint16_t BH1750_ReadData(void);



#endif
