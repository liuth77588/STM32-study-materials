#ifndef __LIGHT_H
#define __LIGHT_H

#include "public.h"
uint16_t BH1750_ReadData(void);
#endif

