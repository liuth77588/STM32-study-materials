


#ifndef __GLOBALDATASTRUCT_H
#define __GLOBALDATASTRUCT_H

#include "public.h"




#endif