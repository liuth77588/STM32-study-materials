#ifndef __DHT11_H
#define __DHT11_H

#include "public.h"

#define DHT11_DQ_L   GPIO_ResetBits(GPIOG,GPIO_Pin_9);
#define DHT11_DQ_H   GPIO_SetBits(GPIOG,GPIO_Pin_9);
#define READ_DA      GPIO_ReadInputDataBit(GPIOG,GPIO_Pin_9)

void DTH11_Init(void);
uint8_t DHT11_Read_Data(uint32_t *data);

#endif
