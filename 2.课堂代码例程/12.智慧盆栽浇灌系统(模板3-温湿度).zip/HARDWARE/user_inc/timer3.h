#ifndef __TIMER3_H
#define __TIMER3_H

#include "public.h"

void TIM3_IntInit(void);


#endif

