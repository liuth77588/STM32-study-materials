#ifndef __IIC2_H
#define __IIC2_H

#include "public.h"


#define RCC_IIC2_SCL   RCC_AHB1Periph_GPIOA //�˿�ʱ��
#define IIC2_SCL_PORT  GPIOA				   //�˿ں�
#define IIC2_SCL 	  GPIO_Pin_2		   //����

#define RCC_IIC2_SDA   RCC_AHB1Periph_GPIOA
#define	IIC2_SDA_PORT  GPIOA
#define	IIC2_SDA 	  GPIO_Pin_3

//io����

#define IIC2_SCL_H     GPIO_SetBits(IIC2_SCL_PORT,IIC2_SCL);  //SCL��1
#define	IIC2_SCL_L     GPIO_ResetBits(IIC2_SCL_PORT,IIC2_SCL);//SCL��0

#define IIC2_SDA_H     GPIO_SetBits(IIC2_SDA_PORT,IIC2_SDA);  //SDA��1
#define	IIC2_SDA_L     GPIO_ResetBits(IIC2_SDA_PORT,IIC2_SDA);//SDA��0

#define READ2_SDA 	  GPIO_ReadInputDataBit(IIC2_SDA_PORT,IIC2_SDA)//��ȡSDA�������ŵ�ƽ

void IIC2_GPIO_Init(void);
void IIC2_SDA_OUT(void);
void IIC2_SDA_IN(void);
void IIC2_Start(void);
void IIC2_Stop(void);
void IIC2_ACK(void);
void IIC2_NACK(void);
void IIC2_SendByte(uint8_t data);
uint8_t IIC2_ReadByte(uint8_t ack);
uint8_t IIC2_WaitACK(void);
uint16_t BH1750_ReadData(void);



#endif
