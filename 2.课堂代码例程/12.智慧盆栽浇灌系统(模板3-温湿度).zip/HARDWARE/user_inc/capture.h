#ifndef __CAPTURE_H
#define __CAPTURE_H

void TIMx_Capture_Config(void);
static void TIMx_GPIO_Config(void);
static void TIMx_NVIC_Config(void);

#endif

