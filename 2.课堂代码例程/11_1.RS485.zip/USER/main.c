#include "public.h"


extern uint8_t uart2_buff[];
extern uint16_t uart_p;

int main(void)
{
	//2�ŷ��飺2bit����ռ  2bit����Ӧ   0-3  0-3 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 
	SysTick_Init();
	USART_Init_Config();
	
	
	RS485_Init_Config();
	
	RS485_SendString("AAABBBCCC123");
	
	uint8_t i=0;
	
	while(1)
	{
		

		
			for(i=0;i<uart_p;i++)
			{
				GPIO_SetBits(GPIOG,GPIO_Pin_8);
				RS485_SendByte(uart2_buff[i]);
				GPIO_ResetBits(GPIOG,GPIO_Pin_8);
			}
			
		
	}	
}






