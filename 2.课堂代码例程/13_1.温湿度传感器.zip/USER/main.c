#include "public.h"



int main(void)
{
	//2�ŷ��飺2bit����ռ  2bit����Ӧ   0-3  0-3 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 
	SysTick_Init();
	USART_Init_Config();
	DHT11_Init();
	
	uint32_t  data=0;
	
	

	
	while(1)
	{
		
		Delay_ms(1000);
		
		DHT11_Read_Data(&data);
		

		printf("�¶� %d.%d\r\n",(data&0x0000FF00)>>8,(data&0x000000FF)>>0);
		
		printf("ʪ�� %d.%d\r\n",(data&0xFF000000)>>24,(data&0x00FF0000)>>16);
		
	}	
}






