#ifndef __WWDG_H
#define __WWDG_H

void WWDG_Init_Config(void);

#endif
