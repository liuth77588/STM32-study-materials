#ifndef __DHT11_H
#define __DHT11_H

#include "public.h"


#define DHT11_DQ_PORT GPIOG					// �˿�
#define DHT11_DQ GPIO_Pin_9					// ����

// IO��������
#define DHT11_DQ_H GPIO_SetBits(DHT11_DQ_PORT,DHT11_DQ);		//DHT11��1
#define DHT11_DQ_L GPIO_ResetBits(DHT11_DQ_PORT,DHT11_DQ);		//DHT11��0
#define READ_DQDA GPIO_ReadInputDataBit(DHT11_DQ_PORT, DHT11_DQ)   // ��ȡDHT11�������ŵ�ƽ


static void DHT11_IO_OUT(void);
uint8_t DHT11_Init(void);
static uint8_t DHT11_Check(void) ;
static void DHT11_RST(void);
static uint8_t DHT11_Read_Bit(void);
static uint8_t DHT11_Read_Byte(void);
uint8_t DHT11_Read_Data(uint32_t *data);
static void DHT11_IO_IN(void);
static void DHT11_IO_OUT(void);


#endif
