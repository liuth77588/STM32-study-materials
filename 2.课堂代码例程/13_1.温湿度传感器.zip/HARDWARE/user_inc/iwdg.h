#ifndef __IWDG_H
#define __IWDG_H

void IWDG_Init_Config(void);

#endif


