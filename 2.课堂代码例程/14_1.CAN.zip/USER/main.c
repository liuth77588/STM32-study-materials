#include "public.h"




int main(void)
{
	uint8_t msg[8]={45,46,48,45,16,16,25,22};
	uint8_t canbuf[8];
	
	//2�ŷ��飺2bit����ռ  2bit����Ӧ   0-3  0-3 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 
	SysTick_Init();
	USART_Init_Config();
	KEY_Init();
	LED_Init();
	
	
	
	CAN_Config();
	
	
	
	uint8_t k =0 ;
	uint8_t i =0;
	while(1)
	{
		
		if(GetStaKey()==true)
		{
			CAN1_Send_Msg(msg);
			GPIO_ToggleBits(GPIOF,GPIO_Pin_9);
		}
			
		
		Delay_ms(1);
		
		k=CAN1_Receive_Msg(canbuf);
	
		if(k)
		{
			for(i=0;i<k;i++)
			{
				printf("%d  ",canbuf[i]);
			}
		}
	}	


}