#ifndef __CAN_H
#define __CAN_H
#include "public.h"

void CAN_Config(void);
uint8_t CAN1_Send_Msg(uint8_t * msg);
uint8_t CAN1_Receive_Msg(uint8_t *buf);



#endif

