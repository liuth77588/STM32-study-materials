#ifndef __PUBLIC_H
#define __PUBLIC_H

#include "stm32f4xx.h"
#include "led.h"
#include "key.h"
#include "exti.h"
#include "timer.h"
#include "pwm.h"
#include "SysTick.h"
#include "capture.h"
#include "iwdg.h"
#include "wwdg.h"



#endif
