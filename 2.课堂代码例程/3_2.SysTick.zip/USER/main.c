#include "stm32f4xx.h"
#include "led.h" 
#include "key.h"
#include "exti.h"
#include "timer.h"
#include "SysTick.h"


int main(void)
{
	SysTick_Init();
	LED_Init();
	while (1)
	{
		
		GPIO_SetBits(GPIOF,GPIO_Pin_10);  
		Delay_ms(1000);   //��ʱ1000ms ��Ҳ����1s
	   
		GPIO_ResetBits(GPIOF,GPIO_Pin_10); 
		Delay_ms(1000);
	     
	}
		

}








