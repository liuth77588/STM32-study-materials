#ifndef __LED_H
#define __LED_H	
#include "stm32f4xx.h"

void LED_Init(void);//��ʼ��	

#endif
