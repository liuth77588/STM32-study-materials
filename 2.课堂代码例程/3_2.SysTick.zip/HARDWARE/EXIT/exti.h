#ifndef __EXTI_H
#define __EXIT_H	 
#include "stm32f4xx.h"


void EXIT_Init(void);

#endif

























