#ifndef __TIMER_H
#define __TIMER_H	
#include "stm32f4xx.h"

void TIM6_Init(void);	

#endif
