#ifndef __PWM_H
#define __PWM_H


void TIMx_GPIO_Init(void);
void TIMx_PWM_Config(void);
#endif
