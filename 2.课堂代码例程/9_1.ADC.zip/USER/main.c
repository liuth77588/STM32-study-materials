#include "public.h"

extern float ADC_Vol;

int main(void)
{
	//2�ŷ��飺2bit����ռ  2bit����Ӧ   0-3  0-3 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 
	SysTick_Init();
	
	USART_Init_Config();
	
	ADC_Init_Config();
	
	while(1)
	{
		printf("��ѹֵΪ��%f \r\n",ADC_Vol);
		Delay_ms(500);
	}	
}






